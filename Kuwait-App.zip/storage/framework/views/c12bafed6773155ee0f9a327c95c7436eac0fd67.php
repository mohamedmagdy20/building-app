<?php $__env->startSection('title','Advertis'); ?>
<?php $__env->startSection('content'); ?>
   <!-- start page title -->
   <div class="row">
    <div class="col-12">
        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">Advertis List</h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>">DashBoard</a></li>
                    </li>
                    <li class="breadcrumb-item active">Advertis</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Advertis List</h4>
                <div class="text-center mb-3">
                    <a href="<?php echo e(route('admin.Advertise.create')); ?>" class="btn btn-primary">Add Advertis <i
                            class="fa fa-plus"></i>
                    </a>
                </div>
                <table id="datatable-buttons" class="table dt-responsive nowrap w-100">
                    <thead>
                        <tr>
                           <th>Image</th>
                           <th>Url</th>
                           <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>

                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>

                            <td><img width="100" height="100" src="<?php echo e($item->image); ?>"  /></td>
                            <td><a href="<?php echo e($item->url); ?>" target="__blank"><?php echo e($item->url); ?></a> </td>
                             <td>
                                <a href="<?php echo e(route('admin.Advertise.edit',$item->id)); ?>" class="btn btn-primary"><i class="fa fa-pen"></i></a>
                                <a href="<?php echo e(route('admin.Advertise.delete',$item->id)); ?>" class="btn btn-danger delete-confirm"><i class="fa fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>

            </div> <!-- end card body-->
        </div> <!-- end card -->
    </div><!-- end col-->
</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $('#datatable-buttons').DataTable();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\client\Oraby\Kuwait-App\resources\views/dashboard/Advertises/index.blade.php ENDPATH**/ ?>