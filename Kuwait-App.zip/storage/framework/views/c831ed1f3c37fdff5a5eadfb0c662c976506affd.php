<?php switch($type):
    case ('action'): ?>
        <?php if($data->deleted_at == null): ?>
        <a href="<?php echo e(route('admin.user.show',$data->id)); ?>" class="btn btn-info"> <i class="fa fa-eye"></i></a>                    
        <?php else: ?>
        <a href="<?php echo e(route('admin.user.force.delete',$data->id)); ?>" class="btn btn-danger"><i class="fa fa-trash"></i></a>
        <?php endif; ?>
    
        <?php break; ?>
    <?php case ('status'): ?>
    <input type="checkbox" id="switch1" switch="none" onchange="toggleData(<?php echo e($data->id); ?>)" <?php echo e($data->deleted_at == null ? 'checked' : ''); ?>  />
    <label for="switch1"></label>

    <?php break; ?>
    <?php case ('image'): ?>
        <div class="py-1">
            <img src="<?php echo e($data->image != null ? asset('uploads/users/'.$data->image) : asset('assets/images/users/avatar-1.jpg')); ?>"  class="img-thumbnail w-75  rounded-1" alt="<?php echo e($data->name); ?>">
        </div>
    <?php break; ?>
    <?php case ('points'): ?>
    <div class="w-50">
        <input type="text" name="points" onchange="updatePoints(<?php echo e($data->id); ?>)" <?php echo e($data->deleted_at !=null ? 'readonly' : ''); ?>  disable value="<?php echo e($data->points); ?>" id="points" class="form-control">
    </div>
    <?php break; ?>
    <?php case ('account_type'): ?>
        <?php if($data->account == 'normal'): ?>
            <p class="btn btn-sm btn-info"><?php echo e($data->account_type); ?></p>        
        <?php else: ?>
            <p class="btn btn-sm btn-warning text-white"><?php echo e($data->account_type); ?></p>        
        <?php endif; ?>
    <?php break; ?>
    <?php default: ?>
        
<?php endswitch; ?><?php /**PATH F:\client\Oraby\Kuwait-App\resources\views/dashboard/users/action.blade.php ENDPATH**/ ?>