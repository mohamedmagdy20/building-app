<?php

return [
    'USER_PATH'=>'uploads/users/',
    'ADS_PATH'=>'uploads/ads/',
];