<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\AdvertismentRequest;
use App\Http\Resources\AdvertismentResource;
use App\Http\Resources\ArchitectureResource;
use App\Http\Resources\CommercialResource;
use App\Http\Resources\LandResource;
use App\Http\Resources\ResidentialResource;
use App\Models\AdsFavorite;
use App\Models\Advertisment;
use App\Models\AdvertismentImage;
use App\Models\Draft;
use App\Traits\FilesTrait;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AdvertismentController extends Controller
{
    //
    use FilesTrait;
    protected $model;
    protected $modelImage;
    protected $adsFavorite;
    public function __construct(Advertisment $model , AdvertismentImage $modelImage, AdsFavorite $adsFavorite)
    {
        $this->model = $model;
        $this->adsFavorite=  $adsFavorite;
        $this->modelImage =$modelImage;
    }
    public function store(AdvertismentRequest $request)
    {
        $data = $request->validated();
        return $data;
        try{
            DB::beginTransaction();

            $ads =$this->model->create(array_merge($data,['user_id'=>$this->auth($request->access_token)->id]));
            
            if($request->hasFile('image_1'))
            {
                $imageName = $this->saveFile($request->file('image_1'),config('filepath.ADS_PATH'));
                $this->modelImage->create(['advertisment_id'=>$ads->id,'image'=>$imageName]);
            }

            if($request->hasFile('image_2'))
            {
                $imageName = $this->saveFile($request->file('image_2'),config('filepath.ADS_PATH'));
                $this->modelImage->create(['advertisment_id'=>$ads->id,'image'=>$imageName]);
            }

            if($request->hasFile('image_3'))
            {
                $imageName = $this->saveFile($request->file('image_3'),config('filepath.ADS_PATH'));
                $this->modelImage->create(['advertisment_id'=>$ads->id,'image'=>$imageName]);
            }     
            if($request->hasFile('image_4'))
            {
                $imageName = $this->saveFile($request->file('image_4'),config('filepath.ADS_PATH'));
                $this->modelImage->create(['advertisment_id'=>$ads->id,'image'=>$imageName]);
            }

            if($request->hasFile('image_5'))
            {
                $imageName = $this->saveFile($request->file('image_5'),config('filepath.ADS_PATH'));
                $this->modelImage->create(['advertisment_id'=>$ads->id,'image'=>$imageName]);
            }

            DB::commit();
            return response()->json([
                'status'=>200,
                'message'=>'Advertisment Added',
                'data'=> new AdvertismentResource($ads)
            ]);
        }catch(Exception $e)
        {
            DB::rollBack();
            return response()->json([
                'status' => 400,
                'message'=> $e->getMessage(),
                'data'=>null
            ]);
        }
    }

    public function show(Request $request)
    {
        $data = $this->model->with('category')->find($request->get('id'));
        if($data)
        {
            if($data->category->type == 'residential')
            {
                $resources = new ResidentialResource($data);
            }elseif($data->category->type == 'commercial')
            {
                $resources = new CommercialResource($data);   
            }elseif($data->category->type == 'lands')
            {
                $resources = new LandResource($data);   
            }elseif($data->category->name_en == 'Architecture')
            {
                $resources = new ArchitectureResource($data);
            }
            return response()->json(
                [
                    'status'=>200,
                    'message'=>'Success',
                    'data'=> $resources
                ]
            );
        }else{
            return response()->json(
                [
                    'status'=>404,
                    'message'=>'Not Found',
                    'data'=> null
                ]
            );
        }
        
    }

    public function specialAds(Request $request)
    {
        return response()->json([
            'status'=>200,
            'message'=>'Success',
            'data'=>AdvertismentResource::collection($this->model->special()->latest()->get())
        ], 200);
    }

    public function index(Request $request)
    {
        $data = $this->model->orderByRaw("FIELD(ads_type, 'fixed', 'normal')")->filter($request->all())->latest()->simplePaginate(7);
        return response()->json([
            'status'=>200,
            'message'=>'Success',
            'data'=>AdvertismentResource::collection($data)
        ], 200);
    }



    public function addFavorate(Request $request)
    {
        $ads = $this->adsFavorite->create(['user_id'=>$this->auth($request->access_token)->id,'advertisment_id'=>$request->id]);
        return response()->json([
            'status'=>200,
            'message'=>'Success',
            'data'=>null
        ], 200);
    }

    public function favoriteAds(Request $request)
    {
        $IDs = $this->adsFavorite->where('user_id',$this->auth($request->access_token))->pluck('advertisment_id');
        $data =  $this->model->whereIn('id',$IDs)->simplePaginate(7);
        return response()->json([
            'status'=>200,
            'message'=>'Success',
            'data'=>AdvertismentResource::collection($data)
        ], 200);
    }

    // private function AdsImageLinks($images)
    // {
    //     $arrLink = [];
    //     foreach($images as $index => $image)
    //     {
    //         $arrLink[$index] = asset('uploads/ads/'.$image->image);
    //     }
    //     return $arrLink;
    // }
    
}
